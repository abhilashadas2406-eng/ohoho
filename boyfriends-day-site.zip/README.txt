Boyfriend's Day website
=======================
Files: index.html + images/ folder (keep them together).

Run on your computer: double-click index.html.
Password: 1524 (change it: open index.html, search for  var CODE="1524"  )
Change letter text: search for  <div class="letter">  in index.html.
Change photos: replace the files in images/ keeping the same names.

Deploy free (pick one):
1. Netlify Drop: go to app.netlify.com/drop and drag this whole folder in.
2. GitHub Pages: upload the files to a repo, then Settings > Pages > deploy from main branch.
3. Vercel: run  npx vercel  inside this folder.

Note: the password is checked in the page's code, so it's a fun lock, not real security.
